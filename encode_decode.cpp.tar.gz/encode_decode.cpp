//#include "ICANCmd.h"
#include <iomanip>
#include <iostream>

using namespace std;
struct can_data{
	unsigned int uID=1;
	unsigned char arrData[8];

} canDataFrame;

can_data Dec2Hex(float number);
int main(int argc,char **argv)
{

	float num=-1000.10211;
	cout << setprecision(12)<<num << endl;
	canDataFrame = Dec2Hex(num);

	return 0;

}

can_data Dec2Hex(float number)//返回一个数组
{

	/*
数据转换后的形式
							7		6		5		4		3		2		1		0
arrData[0]                      <----   lsb
arrData[1]                      <----  
arrData[2]                      <----  
									.......
arrData[i]            msb       <----
									.......
arrData[7]		0		0		0		0		0		0		0		0    
*/
	int numberEnCode;
	//上级接收到数据之后，乘以1000,可以保留三位小数，然后加一千万，将负数变为正数(注意：此数字绝对值在10000范围内,若想存更大的数字，则将加的数变大就是)
	numberEnCode = number * 1000 + 10000000;
	cout << numberEnCode << endl;
	can_data objCan; //一百万只需要五位16进制数据保存
	int flag;
	for (int i = 0; i < 8; ++i) //全部置0
	{
		objCan.arrData[i]=0x00;
		for (int j = 0; (j < 8) && (numberEnCode != 0); ++j) //操作每一位unsigned char，看置0还是1
		{

			flag = numberEnCode % 2;
			
			if(flag==1)
			{
				objCan.arrData[i]^=1<<j;
			}
			numberEnCode = numberEnCode / 2;
		}
    
    }

		//将我的转换后的数据的形式显示出来
		cout << "           "
				 << "76543210" << endl;
		for (int i = 0; i < 8; ++i)
		{
			cout << "arrData[" << i << "] ";
			for (int j = 0; j < 8; ++j)
			{
				cout << ((objCan.arrData[i] >> 7 - j) & 1);
			}

			cout << endl;
		}
			return objCan;
}
